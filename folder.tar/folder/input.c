/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   input.c                                            :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: hcho <marvin@42.fr>                        +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2020/12/07 10:05:17 by hcho              #+#    #+#             */
/*   Updated: 2020/12/08 11:36:21 by hcho             ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>
#include <stdlib.h>
#include "file_util.h"
#include "ptr_util.h"
#include "process.h"
#include "solve.h"
#include <stdio.h>

void	print_error(void)
{
	write(1, "map error\n", 10);
}

void	input_keyboard(void)
{
	char *keyboard_str;

    read(0, keyboard_str, 1000);
	if (!keyboard_str)
	{
		print_error();
		return ;
	}
	size = find_mapsize(keyboard_str);
	charset = find_mapcharset(keyboard_str);
	if (!size || !charset)
	{
		print_error();
		return ;
	}


}

void	input_file(char *file)
{
	char	*file_str;
	int		size;
	char	*charset;
	int		**map;

	file_str = read_file(file);
	if (!file_str)
	{
		print_error();
		return ;
	}
	size = find_mapsize(file_str);
	charset = find_mapcharset(file_str);
	if (!size || !charset)
	{
		print_error();
		return ;
	}
	map = find_map(size, charset, file_str);
	free(file_str);
	if (!map)
	{
		print_error();
		free(charset);
		return ;
	}
	solve_map(size, charset, map);
	free_map(map);
	free(charset);
}
