/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   process.h                                          :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: hcho <marvin@42.fr>                        +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2020/12/07 11:42:52 by hcho              #+#    #+#             */
/*   Updated: 2020/12/08 11:24:45 by hcho             ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef PROCESS_H
# define PROCESS_H

int		find_mapsize(char *info);
char	*find_mapcharset(char *info);
int		make_map(int **map, int line, char *line_info, char *charset, int size);
int		**find_map(int size, char *charset, char *info);

#endif
