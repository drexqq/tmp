/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   solve.c                                            :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: hcho <marvin@42.fr>                        +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2020/12/07 10:06:26 by hcho              #+#    #+#             */
/*   Updated: 2020/12/08 10:38:06 by hcho             ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef SOLVE_H
# define SOLVE_H

int		g_max;
int		g_position[2];
int		compare(int a, int b);
int		get_min(int **map, int i, int j);
int		check(int value);
void	print_solution(int size, int **map, char *charset);
void	solve_map(int size, char *charset, int **map);

#endif
