/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   process.c                                          :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: hcho <marvin@42.fr>                        +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2020/12/07 11:42:52 by hcho              #+#    #+#             */
/*   Updated: 2020/12/08 11:24:35 by hcho             ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdlib.h>
#include "ft_split.h"
#include "ptr_util.h"
#include "str_util.h"

int		find_mapsize(char *info)
{
	int size;
	int first_len;
	int len;

	first_len = 0;
	while (*(info + first_len) && *(info + first_len) != '\n')
		first_len++;
	if (first_len <= 3)
		return (0);
	len = 0;
	size = 0;
	while (len < first_len - 3)
	{
		if (*(info + len) < '0' || *(info + len) > '9')
			return (0);
		size = 10 * size + (*(info + len) - '0');
		len++;
	}
	return (size);
}

char	*find_mapcharset(char *info)
{
	char	*charset;
	int		len;
	int		i;
	int		valid;

	len = 0;
	while (*(info + len) && *(info + len) != '\n')
		len++;
	if (len <= 3)
		return (0);
	valid = 1;
	charset = (char *)malloc(sizeof(char) * 4);
	i = -1;
	while (++i < 3)
	{
		if (*(info + i + len - 3) < 32 || *(info + i + len - 3) > 126)
			valid = 0;
		*(charset + i) = *(info + i + len - 3);
	}
	*(charset + i) = '\0';
	valid = (charset[0] == charset[1] || charset[0] == charset[2]) ? 0 : valid;
	valid = (charset[1] == charset[2]) ? 0 : valid;
	if (!valid)
		free(charset);
	return (charset);
}

int		make_map(int **map, int line, char *line_info, char *charset, int size)
{
	int len;
	int valid;

	valid = 1;
	valid = (ft_strlen(line_info) == size) ? valid : 0;
	map[line - 1] = (int *)malloc(sizeof(int) * ft_strlen(line_info));
	len = -1;
	while (*(line_info + (++len)))
	{
		if (*(line_info + len) == charset[0])
			*(map[line - 1] + len) = 1;
		else if (*(line_info + len) == charset[1])
			*(map[line - 1] + len) = 0;
		else
			valid = 0;
	}
	return (valid);
}

int		**find_map(int size, char *charset, char *info)
{
	int		**map;
	char	**line_info;
	int		i;
	int		valid;

	valid = 1;
	i = 0;
	line_info = ft_split(info, "\n");
	if (ptrlen(line_info) != size + 1)
	{
		free_double(line_info);
		return (0);
	}
	map = (int **)malloc(sizeof(int *) * size);
	while (line_info[++i])
		valid = valid && make_map(map, i, line_info[i], charset, size);
	free_double(line_info);
	if (!valid)
	{
		free_map(map);
		return (0);
	}
	return (map);
}
