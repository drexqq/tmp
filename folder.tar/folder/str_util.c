/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   str_util.c                                         :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: hcho <hcho@42.fr>                          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2020/12/04 22:34:04 by hcho              #+#    #+#             */
/*   Updated: 2020/12/07 20:19:27 by hcho             ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>
#include <stdlib.h>

int		ft_strlen(char *str)
{
	int len;

	len = 0;
	while (*(str + len))
		len++;
	return (len);
}

void	ft_putstr(char *str)
{
	int len;

	len = 0;
	while (*(str + len))
		write(1, str + (len++), 1);
}

int		line_count(char *str)
{
	int len;
	int count;

	len = 0;
	count = 0;
	while (*(str + len))
	{
		count = (*(str + len) == '\n') ? count + 1 : count;
		len++;
	}
	return (count);
}
