/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main.c                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: hcho <marvin@42.fr>                        +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2020/12/07 09:59:52 by hcho              #+#    #+#             */
/*   Updated: 2020/12/08 11:34:52 by hcho             ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdlib.h>
#include <unistd.h>
#include "input.h"

int	main(int argc, char *argv[])
{
	int i;

	if (argc == 1)
		input_keyboard();
	else
	{
		i = 1;
		while (i < argc)
		{
			input_file(argv[i]);
            write(1, "\n", 1);
			i++;
		}
	}
	system("leaks BSQ > leaks_result_temp; cat leaks_result_temp | grep leaked && rm -rf leaks_result_temp");
	return (0);
}
