/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   file_util.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: hcho <marvin@42.fr>                        +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2020/12/05 11:31:15 by hcho              #+#    #+#             */
/*   Updated: 2020/12/07 20:21:34 by hcho             ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>
#include <fcntl.h>
#include <stdlib.h>
#include "str_util.h"

int		file_len(char *file)
{
	int		fd;
	char	c;
	int		len;

	fd = open(file, O_RDONLY);
	if (fd == -1)
		return (-1);
	else
	{
		len = 0;
		while (read(fd, &c, 1))
			len++;
		close(fd);
	}
	return (len);
}

char	*read_file(char *file)
{
	int		fd;
	int		len;
	char	*file_str;

	len = file_len(file);
	if (len == -1)
		return (0);
	file_str = (char *)malloc(sizeof(char) * (len + 1));
	if (!file_str)
		return (0);
	fd = open(file, O_RDONLY);
	if (fd == -1)
		return (0);
	else
	{
		read(fd, file_str, len);
		close(fd);
	}
	file_str[len] = '\0';
	if (line_count(file_str) <= 1)
	{
		free(file_str);
		return (0);
	}
	return (file_str);
}
