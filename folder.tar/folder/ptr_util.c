/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ptr_util.c                                         :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: hcho <marvin@42.fr>                        +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2020/12/07 14:11:26 by hcho              #+#    #+#             */
/*   Updated: 2020/12/08 10:47:30 by hcho             ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdlib.h>

int		ptrlen(char **ptr)
{
	int len;

	len = 0;
	while (ptr[len])
		len++;
	return (len);
}

void	free_double(char **ptr)
{
	int len;

	len = 0;
	while (ptr[len])
	{
		free(ptr[len]);
		len++;
	}
	free(ptr);
}

void	free_map(int **map)
{
	int len;

	len = 0;
	if (!map)
		return ;
	if (map[len])
	{
		free(map);
		return ;
	}
	while (map[len])
	{
		free(map[len]);
		len++;
	}
	free(map);
}
