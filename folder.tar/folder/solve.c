/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   solve.c                                            :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: hcho <marvin@42.fr>                        +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2020/12/07 10:06:26 by hcho              #+#    #+#             */
/*   Updated: 2020/12/08 10:49:49 by hcho             ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>
#include "input.h"
#include <stdio.h>

int		g_max;
int		g_position[2];

int		compare(int a, int b)
{
	return ((a > b) ? b : a);
}

int		get_min(int **map, int i, int j)
{
	return (compare(compare(map[i - 1][j - 1], map[i - 1][j]), map[i][j - 1]));
}

int		check(int value)
{
	if (value >= 0 && value < g_max)
		return (1);
	return (0);
}

void	print_solution(int size, int **map, char *charset)
{
	int i;
	int j;

	i = -1;
	while (++i < size)
	{
		j = -1;
		while (++j < size)
		{
			if (check(g_position[0] - i) && check(g_position[1] - j))
				write(1, &charset[2], 1);
			else if (map[i][j] > 0)
				write(1, &charset[0], 1);
			else
				write(1, &charset[1], 1);
		}
		write(1, "\n", 1);
	}
}

void	solve_map(int size, char *charset, int **map)
{
	int	i;
	int j;

	g_max = 0;
	i = -1;
	while (++i < size)
	{
		j = -1;
		while (++j < size)
		{
			if (map[i][j] == 0)
				continue;
			if (i != 0 && j != 0)
				map[i][j] = get_min(map, i, j) + 1;
			if (g_max < map[i][j])
			{
				g_max = map[i][j];
				g_position[0] = i;
				g_position[1] = j;
			}
		}
	}
	(g_max > 0) ? print_solution(size, map, charset) : print_error();
}
